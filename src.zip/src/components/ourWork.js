import React, { Component } from "react";
import Navbar from "./navbar";
import Footer from "./footer";

export class OurWork extends Component {
  render() {
    return (
      <div>
        <h1>Our-Work Page...</h1>
      </div>
    );
  }
}

export default OurWork;

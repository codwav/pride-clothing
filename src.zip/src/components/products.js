import React, { Component } from "react";
import Navbar from "./navbar";
import Footer from "./footer";

export class Products extends Component {
  render() {
    return (
      <div>
        <h1>Products Page...</h1>
      </div>
    );
  }
}

export default Products;
